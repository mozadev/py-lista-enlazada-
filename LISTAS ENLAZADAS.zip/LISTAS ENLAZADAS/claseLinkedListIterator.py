# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

class LinkedListIterator:
    def __init__(self, head):
        self.current = head

    def __next__(self):
        if self.current == None:
            raise StopIteration
        else:
            element = self.current.element
            self.current = self.current.next
        return element
        
