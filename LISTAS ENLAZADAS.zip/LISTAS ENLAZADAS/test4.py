# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseLinkedList import LinkedList

lista=LinkedList()
lista.addFirst(13)
lista.addFirst(2)
lista.addFirst(2)
print("al inicio = ",lista.head.element)
print("al final = ",lista.tail.element)

lista.insert(2,9)
print("se inserto = ",lista.head.next.next.element)
print("al final = ",lista.tail.element)

lista.insert(0,11)
print("se inserto = ",lista.head.element)

#11->7->2->9->13
lista.removeLast()
print("en la cola: ",lista.tail.element) #9
