# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseLinkedList import LinkedList

lista1 = LinkedList()
lista1.addLast(10)
lista1.addLast(15)
lista1.addLast(4)
lista1.addLast(20)
lista1.addLast(10)
lista1.addLast(4)
print("Lista 1")
lista1.traverse()

lista2 = LinkedList()
lista2.addLast(8)
lista2.addLast(4)
lista2.addLast(2)
lista2.addLast(10)
lista2.addLast(8)
print("\nLista 2")
lista2.traverse()

lista3 = LinkedList()
print("\nLista 3")

current = lista1.head
while current is not None:
    dato1= current.element
    actual = lista2.head
    index=0
    while actual is not None:
        if dato1==actual.element:
            lista3.addLast(dato1)
            lista2.removeAt(index)
        actual=actual.next
        index=index+1
    current=current.next

lista3.traverse()
