# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseLinkedList import LinkedList
import time

#Lista Python
t_ini = time.time()
lst=[]

#Insertamos 100 000 valores en la lista
for i in range(0,100000):
    lst.insert(i,i)
t_fin=time.time()
elapsed = t_fin - t_ini

#print(lst)
print("Lista Python = %12.8f "%elapsed)

#Lista Enlazada
t_ini = time.time()
linkedlst = LinkedList()

#Insertamos 100 000 valores en la lista
for i in range(0,100000):
    linkedlst.insert(i,i)
t_fin=time.time()
elapsed = t_fin - t_ini

#print(lst)
print("Lista Enlazada = %12.8f "%elapsed)
