# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseLinkedList import LinkedList

lista=LinkedList()
lista.addFirst("Francia")
lista.addFirst("Rusia")
lista.addFirst("America")
lista.addFirst("Canada")
print(lista.getSize())
print(lista)

#Lista Python
lst=["C","A","R","F"]

print("lista Python")
for item in lst:
    print(item)

print("lista enlazada")

#Se puede dar incluyendo un iterador (LinkedListIterator / __iter__ )
for item in lista:
    print(item)

lista.clear()
print( lista )
