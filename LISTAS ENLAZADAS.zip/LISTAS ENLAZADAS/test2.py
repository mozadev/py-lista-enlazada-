# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseLinkedList import LinkedList

lista=LinkedList()
lista.addFirst(14)
lista.addFirst(18)
lista.addFirst(-2)

print("al inicio = ",lista.head.element)
print("al final = ",lista.tail.element)
print("con addlast, agregamos al final el valor 7")
lista.addLast(7)

print("al final = ",lista.tail.element)
lista.addLast(0)
print("al final = ",lista.tail.element)
