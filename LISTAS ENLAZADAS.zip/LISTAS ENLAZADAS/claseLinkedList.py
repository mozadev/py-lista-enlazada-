# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

from claseNode import Node
from claseLinkedListIterator import LinkedListIterator
class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0 #Lista enlazada vacia

    def getFirst(self):
        return self.head.element

    def getLast(self):
        return self.tail.element

    def isEmpty(self):
        if self.size==0:
        #if self.head==None:
            return True
        else:
            return False

    def getSize(self):
        return self.size

    def __str__(self):
        current=self.head
        cad="["
        while current is not None:
            cad=cad+str(current.element)+","
            current = current.next
        cad=cad+"]"
        return cad

    def clear(self):
        self.head=self.tail=None
        self.size=0
        
    def addFirst(self, e):
        newNode = Node(e) #Nuevo nodo
        newNode.next = self.head #Enlazar nuevo nodo con la cabeza
        self.head = newNode #head apunta al nuevo nodo
        self.size += 1  #Aumentar tamaño de la lista
        if self.tail == None: #Nuevo nodo es el único nodo de la lista
            self.tail = self.head

    def addLast(self,e):
        newNode=Node(e)
        self.size+=1
        if self.head==None:
            self.head=newNode
            self.tail=self.head
        else:
            self.tail.next=newNode  #Enlazar el tail al nuevo
            self.tail=newNode #Nodo o si primero lo estableces como
            #Tail no afecta

    def insert(self, index, e):

        if index == 0:
            self.addFirst(e) #Inserta al comienzo

        elif index >= self.size:
            self.addLast(e) #Inserta al final

        else: #Inserta en el medio
            current = self.head
            for i in range(1, index):
                    current = current.next
            temp = current.next
            current.next = Node(e)
            (current.next).next = temp
            self.size += 1

        
    def removeLast(self):
        if self.size == 0:
            return None #No hay elementos
        elif self.size == 1: #Solo hay un elemento en la lista
            temp = self.head
            self.head = self.tail = None #La lista se vuelve vacía
            self.size = 0
            return temp.element
        else:
            current = self.head
            for i in range(self.size - 2):
                current = current.next
                
            temp = self.tail
            self.tail = current
            self.tail.next = None
            self.size -= 1
            return temp.element

    def removeFirst(self):
        if self.size==0:
            return None
        elif self.size==1:
            temp=self.tail
            self.head=self.tail=None
            self.size=0
            return temp.element
        else:
            temp=self.tail
            self.head=self.head.next
            self.size-=1
            return temp.element

    def removeAt(self,index):
        if index<0 or index>=self.size:
            return None
        if index==0:
            self.removeFirst()
        elif index==self.size-1:
            self.removeLast()
        else:
            current=self.head
            for i in range(0,index-1):
                current=current.next

            temp=current.next
            current.next=temp.next
            self.size-=1
            return temp.element
    
    def __iter__(self):
        return LinkedListIterator(self.head)
