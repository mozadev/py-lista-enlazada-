# LABORATORIO 10.1
# Sandro Alonso Robles Alcóser [76287347]

class Node:
    def __init__(self,info):
        self.element = info
        self.next = None
